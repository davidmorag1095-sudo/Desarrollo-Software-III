class Freight:
    """"Entidad del dominio que representa un flete"""
    def __init__(self,number:str,amount:float,customer_id:str,route:tuple,weight:float):
        self.number=number
        self.amount=amount
        self.customer_id=customer_id
        self.route=route
        self.weight=weight
    #convierte el objeto Freight en un diccionario para guardarlo en el JSON

    def to_dict(self):
        return {
            "number":self.number,
            "Amount":self.amount,
            "Customer_id":self.customer_id,
            "route":{"origin":self.route[0],
                     "destination":self.route[1]
                     },
            "Weitht":self.weight}

    #recontruye un objeto Freight a partir de un diccionario
    @classmethod
    def from_dict(cls,data:dict):
        return cls(data["Number"],
                   data["Amount"],
                   data["Customer_id"],
                   (data["route"]["origen"],data["route"]["destination"]),
                   data["Weight"])
