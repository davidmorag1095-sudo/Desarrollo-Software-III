class Customer:
    """"Entidad del dominio que representa al cliente"""
    def __init__(self,identificador:str,name:str,phone:str):
        self.identificador=identificador
        self.name=name
        self.phone=phone

    """convierte el objeto en un diccionario,esto es util para guardarlo en un JSON """
    def to_dict(self)->dict:
        return {"identificador":self.identificador,
                "Name":self.name,
                "Phone":self.phone}

    """Permite reconstruir un objeto cliente,a partir de un diccionario leido desde un JSON"""
    @classmethod
    def from_dict(cls,data:dict):
        return cls(data["Identificador"],
                   data["Name"],
                   data["Phone"])

    def __str__(self)->str:
        return f"ID:{self.identificador},Nombre:{self.name},Telefono:{self.phone}"



