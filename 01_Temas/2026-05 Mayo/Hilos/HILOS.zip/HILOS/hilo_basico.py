""""Ejemplo#1: Hilo basico en Python
Este archivo muestra como crear un hilo sencillo usando threading 
Objetivo:
    Como crear un hilo
    Como iniciar un hilo
    Como esperar a que termine
    """""

import threading
import time
def tarea():
    for i in range(1,6):
        print(f"Hilo trabajando... paso{i}")
        time.sleep(1)

    print("El hilo termino su trabajo")
print("Programa principal iniciando")
#Se crea el hilo indicando la funcion que va a ejecutar
hilo=threading.Thread(target=tarea)


#start () inicia la ejecucion del hilo
hilo.start()

#join() hace que el programa principal espere hasta que el hilo termine

print("Programa principal finalizado")


