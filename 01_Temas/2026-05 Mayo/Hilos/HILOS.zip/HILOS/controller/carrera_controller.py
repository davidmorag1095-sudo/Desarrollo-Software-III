import threading
import time
from queue import Queue,Empty
from random import Random




class CarreraController:
    def __init__(self,carrera,vista):
        self.carrera=carrera
        self.vista=vista

        #Lock para proteger la sesion critica
        self.lock=threading.Lock()
        #cola para enviar los eventos desde los hilos hacia la interface
        self.eventos=Queue()

        #Lista de hilos creados
        self.hilos =[]

        #Bandera de control
        self.detener=False
        self._configurar_vista()

    def _configurar_vista(self):
        """Conecta botones y dibuja la escena incial"""
        self.vista.btn_iniciar.config(command=self.iniciar_carrera)
        self.vista.btn_iniciar.config(command=self.reiniciar_carrera)

        self.vista.dibujar_escena(self.carrera)
        #after() permite revisar periodicamente la cola desde el hilo principal de Tkinter
        self.vista.root.after(50,self.procesar_eventos)

    def procesar_eventos(self):
        """Atiende los eventos enviados por los hilos
        Esta funcion se ejecuta repetidamente en el hilo principal de Tkinter, lo cual evita actualizar la
        interfaz directamente desde hilos secundarios"""
        try:
            while True:
                """remueve y retorna un item de la cola sin bloquear el programa"""
                evento=self.eventos.get_nowait()
                tipo=evento["tipo"]

                if tipo =="avance":
                    self.vista.actualizar_corredor(evento["nombre"],evento["posicion"])
                elif tipo=="estado":
                    self.vista.mostrar_estado(evento["mensaje"])
                elif tipo=="ganador":
                    self.vista.marcar_ganador(evento["nombre"])
                    self.vista.mostrar_estado(f"Gano {evento['nombre']} la carrera")
                    self.vista.activar_inicio()
        except Empty:
            pass
        #Se vuelve a ejecutar la revision de la cola
        self.vista.root.after(50,self.procesar_eventos())

    def mover_corredor(self, corredor):
        """"Funcion que ejecuta cada hilo ,cada corredor avanza en intervalos aleatorios y con pasos aleatorios"""

        while True:
            time.sleep(Random.uniform(0.08,0.25))

            with self.lock:
                if self.detener or self.carrera.ganador is not None:
                    break

                avance=Random.randint(3,15)
                corredor.posicion+=avance

                #No permitimos que sobrepase demaciado la meta
                if corredor.posicion> self.carrera.meta:
                    corredor.posicion=self.carrera.meta

                self.eventos.put(
                    {"tipo":"avance",
                     "nombre":corredor.nombre,
                     "posicion":corredor.posicion}
                )
